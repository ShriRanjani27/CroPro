from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model and label encoders
model = joblib.load('fertilizer_model.pkl')
label_encoders = joblib.load('label_encoders.pkl')

@app.route('/')
def home():
    return render_template('index.html')  # Render your main input page

@app.route('/predict', methods=['POST'])
def predict():
    # Get data from request
    data = request.get_json(force=True)
    
    # Prepare input features for prediction
    soil_type_encoded = label_encoders['Soil Type'].transform([data['soil_type']])[0]
    crop_type_encoded = label_encoders['Crop Type'].transform([data['crop_type']])[0]
    
    features = np.array([[data['temperature'], data['humidity'], data['moisture'],
                          soil_type_encoded, crop_type_encoded,
                          data['nitrogen'], data['potassium'], data['phosphorous']]])
    
    # Make prediction
    prediction = model.predict(features)
    
    return jsonify({'fertilizer': prediction[0]})

if __name__ == '__main__':
    app.run(debug=True)